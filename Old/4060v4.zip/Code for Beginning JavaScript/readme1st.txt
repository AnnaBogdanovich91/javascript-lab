This is the code download for Beginning JavaScript by Wrox Press. 
It contains all of the code, graphics, sounds, and databases used in the examples in the book. 
Simply extract this zip file onto your hard drive, and the examples from the chapters are organized 
into the appropriate folders.